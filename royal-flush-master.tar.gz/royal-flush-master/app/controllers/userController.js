let User = require('../models/User');

let userController = {

  // Add user methods

}

module.exports = userController;
