var mongoose= require('mongoose');

var eventSchema= mongoose.Schema({

  //event Schema



})

var Event= mongoose.model("event", eventSchema);
module.exports=Event;
